/*
 * M27 轉場包：程式本體（設定區在 pages/*.html）
 * 片段照 設定.參數.轉場 的順序輪流用「前一段」「後一段」兩個影片格子：
 *   轉場 1 之前 = 前一段；轉場 1 之後 = 後一段；有第 2 個轉場時再換回前一段（只有一覽頁會這樣用）。
 * 種類：甩鏡、漏光、推擠、擦過、縮放穿越、閃白、圓形擴散
 * 所有動作由 t 算出；漏光的紙紋用整數雜湊先畫好，每次出檔一樣。
 */
(() => {
  const stage = document.getElementById('stage');
  const P = 設定.參數;
  stage.dataset.duration = 設定.長度;
  stage.dataset.fps = 設定.fps;
  const W = 1080, H = 1920;
  const 色 = { 紙: '#F4F1EA', 墨: '#111111', 紅: '#E3301C', 黃: '#FFDD3C' };
  const 格 = (id) => 設定.格子.find((s) => s.id === id);
  const list = (P.轉場 || []).slice().sort((a, b) => a.開始 - b.開始);

  /* ---- 手感常數（2026-11-23 精緻化）：想調動作質感改這裡，設定區不用動 ---- */
  const 手感 = {
    落地秒: 0.45,                    // 轉場結束後，新畫面「落地」的餘韻多長
    落地: { 甩鏡: 0.03, 推擠: 0.02, 擦過: 0.018, 縮放穿越: 0.03, 閃白: 0.022, 圓形擴散: 0.02, 漏光: 0.012 }, // 落地時多放大幾成（只放大不縮小，邊不會露出來）
    甩鏡加速: 0.42,                  // 甩鏡前 42% 加速、後面拉長慢慢煞住（像真的甩鏡頭）
    帶張開: 0.8,                     // 擦過時黃、紅色帶中間拉開 80% 再收攏
    圓白邊: 12,                      // 圓形擴散的圓外圈紙白邊 px
    標籤k: 7, 標籤w: 3,              // 一覽頁的名稱標籤每換一種彈一下
  };
  // 落地餘韻：0 起、頂到 1、再小彈一次（22%）、收回 0；全程 ≥ 0（只放大），所以畫面邊緣永遠蓋滿
  const bump = (q) => (q <= 0 || q >= 1 ? 0 : q < 0.45 ? Math.sin(Math.PI * q / 0.45) ** 2 * (1 - 0.3 * q) : 0.22 * Math.sin(Math.PI * (q - 0.45) / 0.55) ** 2);
  const spring = (p, k = 6.5, w = 2.6) => {
    if (p <= 0) return 0; if (p >= 1) return 1;
    const raw = (q) => 1 - Math.exp(-k * q) * Math.cos(w * Math.PI * q);
    return raw(p) + (1 - raw(1)) * p;
  };
  // 甩鏡位置曲線：前段加速（三次）、後段指數煞車，總和 0→1；速度用差分算，給模糊用
  const whip = (p) => {
    const a = 手感.甩鏡加速;
    if (p <= 0) return 0; if (p >= 1) return 1;
    const m = 0.55;                                            // 加速段結束時走到 55%
    if (p < a) return m * Math.pow(p / a, 3);
    const q = (p - a) / (1 - a), K = 4.5;
    // 煞車段起速要接上加速段終速：用 1 − (1−q)^n 形狀，n 讓兩段速度相等
    const n = (3 * m / a) * (1 - a) / (1 - m);
    return m + (1 - m) * (1 - Math.pow(1 - q, n));
  };

  // 兩個影片格子。後一段的影片從第 1 個轉場開始時才開始走（第 0 秒對齊轉場開始）
  const A = Slots.build(stage, { ...格('前一段'), x: 0, y: 0, w: W, h: H, 自管: true });
  const B = Slots.build(stage, { ...格('後一段'), x: 0, y: 0, w: W, h: H, 自管: true,
    出現: list.length ? list[0].開始 : 0 });
  [A, B].forEach((g) => { g.el.classList.add('clip'); g.el.style.transformOrigin = '50% 50%'; });
  const clips = list.map((_, i) => (i % 2 ? B : A)).concat([list.length % 2 ? B : A]);

  // 橫向動態模糊（SVG，只模糊水平方向）
  const NS = 'http://www.w3.org/2000/svg';
  const defs = document.createElementNS(NS, 'svg');
  defs.setAttribute('width', 0); defs.setAttribute('height', 0);
  defs.style.position = 'absolute';
  defs.innerHTML = '<filter id="m27blur" x="-20%" y="0" width="140%" height="100%" color-interpolation-filters="sRGB">' +
    '<feGaussianBlur id="m27std" stdDeviation="0 0"/></filter>';
  stage.appendChild(defs);
  const std = defs.querySelector('#m27std');

  const mk = (css) => { const d = document.createElement('div'); d.style.cssText = 'position:absolute;pointer-events:none;' + css; stage.appendChild(d); return d; };

  // 閃白
  const flash = mk(`inset:0;z-index:60;background:${P.閃白顏色};opacity:0;`);
  // 擦過：兩條色帶（紅、黃）帶頭掃過，後一段跟在後面露出來
  const band1 = mk(`left:0;top:0;width:1080px;height:1920px;z-index:55;background:${色.黃};opacity:0;`);
  const band2 = mk(`left:0;top:0;width:1080px;height:1920px;z-index:56;background:${色.紅};opacity:0;`);
  // 圓形擴散：紅圓蓋滿 → 後一段從中間的圓擴開
  const circle = mk(`z-index:57;border-radius:50%;background:${P.圓形顏色};opacity:0;`);
  const rim = mk(`z-index:56;border-radius:50%;background:#FFFDF8;opacity:0;`);   // 圓外圈的紙白邊
  // 漏光：暖色光斑（一般疊加，亮的畫面上也看得出暖色）＋奶油色整片洗白＋紙紋
  const leak = mk('inset:0;z-index:58;opacity:0;');
  const wash = mk(`inset:0;z-index:59;background:#FFF3DC;opacity:0;`);
  const paper = document.createElement('canvas');
  paper.width = 540; paper.height = 960;
  paper.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;z-index:61;opacity:0;mix-blend-mode:multiply;pointer-events:none;';
  stage.appendChild(paper);
  {
    // 紙紋：細顆粒＋橫向纖維，整數雜湊，每次一樣
    const ctx = paper.getContext('2d');
    const img = ctx.createImageData(540, 960);
    const ih = (x, y, f) => { let h = (Math.imul(x, 374761393) + Math.imul(y, 668265263) + Math.imul(f, 1442695041)) | 0;
      h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };
    for (let y = 0; y < 960; y++) {
      const fiber = ih(0, y >> 1, 7) * 0.5 + ih(1, y >> 3, 9) * 0.5;
      for (let x = 0; x < 540; x++) {
        const n = ih(x, y, 3) * 0.6 + fiber * 0.4;
        const v = Math.round(255 - n * 46);
        const i = (y * 540 + x) * 4;
        img.data[i] = v; img.data[i + 1] = Math.round(v * 0.985); img.data[i + 2] = Math.round(v * 0.95); img.data[i + 3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);
  }

  // 一覽頁用：左上角標出這是哪一種轉場
  const tag = P.標出種類 ? mk(`left:60px;top:200px;z-index:90;padding:10px 26px;background:${色.墨};color:${色.紙};font:900 52px 'LINE Seed TW';border-radius:12px;transform:rotate(-2deg);`) : null;

  const reset = (el) => { el.style.opacity = 0; el.style.transform = 'none'; el.style.filter = 'none'; el.style.clipPath = 'none'; el.style.zIndex = 1; };
  const show = (el, z) => { el.style.opacity = 1; el.style.zIndex = z; };
  const f2 = (v) => v.toFixed(2);

  // 推擠／擦過方向
  const DIR = { 左: [-1, 0], 右: [1, 0], 上: [0, -1], 下: [0, 1] };

  function draw(tr, p, out, inn) {
    const k = tr.種類;
    const d = DIR[tr.方向 || P.方向] || DIR.左;
    if (k === '甩鏡') {
      // 像鏡頭往一邊甩：兩段並排一起滑過去，速度最快的時候最模糊
      const e = whip(p);
      const off = e * W;
      const vel = p <= 0 || p >= 1 ? 0 : (whip(Math.min(1, p + 0.01)) - whip(Math.max(0, p - 0.01))) / 0.02;
      const vmax = 3 * 0.55 / 手感.甩鏡加速;                       // 加速段終點最快
      const blur = Math.min(1, vel / vmax) * P.甩鏡模糊;
      show(out, 2); show(inn, 3);
      const dx = d[0] || -1;
      out.style.transform = `translateX(${f2(dx * off)}px)`;
      inn.style.transform = `translateX(${f2(dx * off - dx * W)}px)`;
      std.setAttribute('stdDeviation', `${f2(blur)} 0`);
      if (blur > 0.3) { out.style.filter = 'url(#m27blur)'; inn.style.filter = 'url(#m27blur)'; }
    } else if (k === '推擠') {
      const e = R.easeInOut(p);
      show(out, 2); show(inn, 3);
      const L = d[0] ? W : H;
      out.style.transform = `translate(${f2(d[0] * e * L)}px, ${f2(d[1] * e * L)}px)`;
      inn.style.transform = `translate(${f2(d[0] * (e - 1) * L)}px, ${f2(d[1] * (e - 1) * L)}px)`;
    } else if (k === '擦過') {
      // 斜的邊從一邊掃到另一邊：黃帶、紅帶在前，後一段跟在後面
      show(out, 2); show(inn, 3);
      const e = R.easeInOut(p);
      const ang = P.擦過角度;                                     // 邊歪幾度
      const bw = P.擦過帶寬;
      const span = W + H * Math.tan(Math.abs(ang) * Math.PI / 180) + bw * 2;
      const lead = -bw * 2 + e * (span + bw * 2);                 // 最前面那條邊走到哪
      const gap = bw * (1 + 手感.帶張開 * Math.sin(Math.PI * e));  // 中途帶子之間拉開、到邊再收攏（有拖曳感）
      // 方向：clip-path 在元素自己的座標，翻轉用鏡像座標比較簡單
      const X = (x) => (d[0] > 0 ? x : W - x);
      const poly = (x0) => {
        const s = Math.tan(ang * Math.PI / 180) * H;
        const a = X(x0 + s / 2), b = X(x0 - s / 2), e0 = X(-0.1 * W);
        return `polygon(${f2(e0)}px -10%, ${f2(a)}px -10%, ${f2(b)}px 110%, ${f2(e0)}px 110%)`;
      };
      inn.style.clipPath = poly(lead - gap * 2);
      band2.style.opacity = 1; band2.style.clipPath = poly(lead - gap);
      band1.style.opacity = 1; band1.style.clipPath = poly(lead);
      band1.style.zIndex = 4; band2.style.zIndex = 5; inn.style.zIndex = 6;
    } else if (k === '縮放穿越') {
      // 前一段往裡面衝（放大＋淡掉），後一段從大縮回原尺寸
      const cut = 0.5;
      if (p < cut) {
        const q = R.easeIn(p / cut, 2);
        show(out, 3); show(inn, 2);
        out.style.transform = `scale(${(1 + q * (P.縮放倍數 - 1)).toFixed(4)})`;
        out.style.opacity = (1 - q * q).toFixed(4);
        inn.style.transform = `scale(${P.縮放倍數 * 0.75})`;
      } else {
        const q = R.easeOut((p - cut) / (1 - cut), 3);
        show(inn, 3);
        inn.style.transform = `scale(${(P.縮放倍數 * 0.75 + q * (1 - P.縮放倍數 * 0.75)).toFixed(4)})`;
      }
    } else if (k === '閃白') {
      // 白色升上來（前 40%）→ 最白那一格切到後一段 → 慢慢退掉
      const up = 0.4;
      if (p < up) { show(out, 2); flash.style.opacity = R.easeIn(p / up, 2).toFixed(4); }
      else { show(inn, 2); flash.style.opacity = (1 - R.easeOut((p - up) / (1 - up), 2)).toFixed(4); }
    } else if (k === '圓形擴散') {
      // 前 45%：紅圓從中間長大蓋滿；後 55%：後一段從中間的圓擴開
      const cx = P.圓心X, cy = P.圓心Y;
      const Rm = Math.hypot(Math.max(cx, W - cx), Math.max(cy, H - cy)) + 4;
      const half = 0.45;
      if (p < half) {
        show(out, 2);
        const r = R.easeIn(p / half, 2) * Rm;
        Object.assign(circle.style, { opacity: 1, left: f2(cx - r) + 'px', top: f2(cy - r) + 'px', width: f2(2 * r) + 'px', height: f2(2 * r) + 'px' });
        const rr = r > 1 ? r + 手感.圓白邊 : 0;                      // 紅圓外圈一圈紙白邊，跟背景分得開
        Object.assign(rim.style, { opacity: 1, zIndex: 56, left: f2(cx - rr) + 'px', top: f2(cy - rr) + 'px', width: f2(2 * rr) + 'px', height: f2(2 * rr) + 'px' });
      } else {
        const q = R.easeOut((p - half) / (1 - half), 3);
        Object.assign(circle.style, { opacity: 1, left: f2(cx - Rm) + 'px', top: f2(cy - Rm) + 'px', width: f2(2 * Rm) + 'px', height: f2(2 * Rm) + 'px' });
        show(inn, 58);
        inn.style.clipPath = `circle(${f2(q * Rm)}px at ${cx}px ${cy}px)`;
        const rr = q * Rm > 1 ? q * Rm + 手感.圓白邊 : 0;            // 後一段的圓外圈也有紙白邊，壓在紅圓上
        Object.assign(rim.style, { opacity: 1, zIndex: 57, left: f2(cx - rr) + 'px', top: f2(cy - rr) + 'px', width: f2(2 * rr) + 'px', height: f2(2 * rr) + 'px' });
        rim.parentNode.insertBefore(rim, circle.nextSibling);
      }
    } else if (k === '漏光') {
      // 暖色光斑從左下往右上流過，中間整片變奶油色，最亮那一格切到後一段；疊一層紙紋
      const cutAt = 0.45;
      if (p < cutAt) show(out, 2); else show(inn, 2);
      const env = Math.sin(Math.PI * R.clamp(p)) ** 1.2;           // 0 → 1 → 0
      const drift = R.easeInOut(p);
      const s = P.漏光強度;
      const blob = (x, y, rx, ry, c, a) => `radial-gradient(${rx}px ${ry}px at ${f2(x)}px ${f2(y)}px, ${c.replace('A', a.toFixed(3))}, rgba(0,0,0,0) 70%)`;
      const x0 = R.lerp(-300, 1300, drift), y0 = R.lerp(1900, 200, drift);
      const sx = R.lerp(-700, 1500, drift);                       // 斜光帶走到哪
      leak.style.background = [
        `linear-gradient(118deg, rgba(0,0,0,0) ${f2(sx - 260)}px, rgba(255,230,180,0.85) ${f2(sx - 60)}px, rgba(255,250,235,0.95) ${f2(sx)}px, rgba(255,200,130,0.8) ${f2(sx + 90)}px, rgba(0,0,0,0) ${f2(sx + 340)}px)`,
        blob(x0, y0, 900, 700, 'rgba(255,186,110,A)', 0.85),
        blob(x0 + 380, y0 - 520, 520, 820, 'rgba(240,120,50,A)', 0.7),
        blob(x0 - 260, y0 + 300, 600, 420, 'rgba(255,214,150,A)', 0.8),
        blob(R.lerp(1200, 300, drift), R.lerp(300, 1500, drift), 700, 500, 'rgba(236,140,70,A)', 0.6),
      ].join(',');
      leak.style.opacity = (env * s).toFixed(4);
      const peak = Math.max(0, 1 - Math.abs(p - cutAt) / 0.22);   // 切換那幾格整片洗白蓋住接縫
      wash.style.opacity = (R.easeInOut(peak) * 0.92 * Math.min(1, s)).toFixed(4);
      paper.style.opacity = (env * P.紙紋 ).toFixed(4);
    }
  }

  scene((t) => {
    Slots.sync(t);
    reset(A.el); reset(B.el);
    [flash, band1, band2, circle, rim, leak, wash, paper].forEach((o) => { o.style.opacity = 0; o.style.clipPath = 'none'; });
    std.setAttribute('stdDeviation', '0 0');
    // 現在在第幾段、有沒有在轉場中
    let idx = 0, active = null;
    for (let i = 0; i < list.length; i++) {
      const tr = list[i];
      if (t >= tr.開始 + tr.時長) idx = i + 1;
      else if (t >= tr.開始) { active = i; break; }
      else break;
    }
    if (tag) {
      const ni = Math.min(active ?? idx, list.length - 1), n = list[ni];
      tag.textContent = n ? n.種類 : ''; tag.style.opacity = n ? 1 : 0;
      // 名稱換掉的那一刻（上一個轉場結束）彈一下
      const prevEnd = active === null && idx > 0 ? list[idx - 1].開始 + list[idx - 1].時長 : -9;
      const ts = spring(R.prog(t, prevEnd, 0.4), 手感.標籤k, 手感.標籤w);
      tag.style.transform = `rotate(${f2(-2 - 4 * (1 - ts))}deg) scale(${(0.8 + 0.2 * ts).toFixed(4)})`;
      tag.style.transformOrigin = '0% 50%';
    }
    if (active === null) {
      const cur = clips[idx].el;
      show(cur, 2);
      // 落地餘韻：剛換過來的畫面輕輕「咚」一下（只放大），不是瞬間停死
      const prev = list[idx - 1];
      if (prev) {
        const q = (t - prev.開始 - prev.時長) / 手感.落地秒;
        const A = 手感.落地[prev.種類] || 0;
        if (q > 0 && q < 1 && A) cur.style.transform = `scale(${(1 + A * bump(q)).toFixed(5)})`;
      }
      return;
    }
    const tr = list[active];
    draw(tr, R.prog(t, tr.開始, tr.時長), clips[active].el, clips[active + 1].el);
  });
  Slots.wrapSeek();
})();
