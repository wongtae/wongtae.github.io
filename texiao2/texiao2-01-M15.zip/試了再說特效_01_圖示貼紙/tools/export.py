#!/usr/bin/env python3
"""
匯出輪播：每頁一張 PNG（停在 data-cover 那一秒）、可選 MP4、總覽圖。

  python3 export.py 我的輪播                       # 全部頁面 → out/v1/*.png + _overview.png
  python3 export.py 我的輪播 --mp4                 # 另外把 data-motion="animated" 的頁出 MP4
  python3 export.py 我的輪播 --mp4-all             # 每頁都出 MP4
  python3 export.py 我的輪播 --pages 01,03         # 只出指定頁
  python3 export.py 我的輪播 --at 1.2 --pages 02   # 指定秒數的定格（檢查動畫中途用）
  python3 export.py 我的輪播 --reels               # 另外輸出放進 1080x1920 畫面的版本
  python3 export.py 我的輪播 --serve               # 開本機網址在瀏覽器預覽（會自動播放）

做法：用本機 http 伺服器開頁面（字型走相對路徑）→ Playwright 無頭 Chrome →
每格呼叫 window.seek(t)、截 #stage → PNG，或把所有格交給 ffmpeg 接成 MP4（H.264、yuv420p）。
"""
import argparse
import functools
import http.server
import io
import re
import subprocess
import sys
import threading
import time
from pathlib import Path


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()


def serve(root: Path):
    handler = functools.partial(QuietHandler, directory=str(root))
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return httpd, httpd.server_address[1]


def launch(pw):
    errors = []
    for kw in ({"channel": "chrome"}, {}):
        try:
            return pw.chromium.launch(**kw)
        except Exception as e:  # noqa: BLE001
            errors.append(str(e).splitlines()[0])
    sys.exit("[需要使用者協助] 找不到可用的瀏覽器。請安裝 Google Chrome，或執行："
             "python3 -m playwright install chromium\n" + "\n".join(errors))


def next_out(proj: Path) -> Path:
    base = proj / "out"
    base.mkdir(exist_ok=True)
    nums = [int(m.group(1)) for d in base.iterdir() if d.is_dir() and (m := re.fullmatch(r"v(\d+)", d.name))]
    out = base / f"v{max(nums, default=0) + 1}"
    out.mkdir()
    return out


def css_color_to_hex(c: str) -> str:
    nums = [int(float(x)) for x in re.findall(r"[\d.]+", c)[:3]]
    return "#{:02X}{:02X}{:02X}".format(*nums) if len(nums) == 3 else "#000000"


def overview(pngs: list, out: Path):
    from PIL import Image, ImageDraw
    ims = [Image.open(p).convert("RGB") for p in pngs]
    if not ims:
        return None
    tw = 360
    th = round(ims[0].height * tw / ims[0].width)
    cols = min(len(ims), 5)
    rows = (len(ims) + cols - 1) // cols
    gap, lab = 24, 40
    sheet = Image.new("RGB", (cols * tw + (cols + 1) * gap, rows * (th + lab) + (rows + 1) * gap), (30, 30, 30))
    d = ImageDraw.Draw(sheet)
    for k, (im, p) in enumerate(zip(ims, pngs)):
        x = gap + (k % cols) * (tw + gap)
        y = gap + (k // cols) * (th + lab + gap)
        sheet.paste(im.resize((tw, th), Image.LANCZOS), (x, y))
        d.text((x, y + th + 8), p.stem, fill=(220, 220, 220))
    path = out / "_overview.png"
    sheet.save(path)
    return path


def main():
    ap = argparse.ArgumentParser(description="匯出輪播")
    ap.add_argument("project")
    ap.add_argument("--pages", default="", help="只出這幾頁（檔名開頭的編號，逗號分隔）")
    ap.add_argument("--mp4", action="store_true", help="data-motion=animated 的頁另外出 MP4")
    ap.add_argument("--mp4-all", action="store_true", help="每頁都出 MP4")
    ap.add_argument("--at", type=float, default=None, help="PNG 改停在這一秒（預設用每頁的 data-cover）")
    ap.add_argument("--reels", action="store_true", help="另外輸出置中放進 1080x1920 的版本")
    ap.add_argument("--fps", type=int, default=None, help="覆蓋每頁的 data-fps")
    ap.add_argument("--crf", type=int, default=18)
    ap.add_argument("--out", default=None, help="輸出資料夾（預設 out/v1、v2…自動編號）")
    ap.add_argument("--serve", action="store_true", help="只開本機預覽網址")
    a = ap.parse_args()

    proj = Path(a.project).resolve()
    pages = sorted((proj / "pages").glob("*.html"))
    if a.pages:
        keys = [k.strip() for k in a.pages.split(",") if k.strip()]
        pages = [p for p in pages if any(p.name.startswith(k) for k in keys)]
    if not pages:
        sys.exit(f"{proj / 'pages'} 裡沒有符合的頁面")

    httpd, port = serve(proj)
    if a.serve:
        print("在瀏覽器打開（Ctrl+C 結束）：")
        for p in pages:
            print(f"  http://127.0.0.1:{port}/pages/{p.name}")
        try:
            while True:
                time.sleep(3600)
        except KeyboardInterrupt:
            return

    from playwright.sync_api import sync_playwright

    out = Path(a.out).resolve() if a.out else next_out(proj)
    out.mkdir(parents=True, exist_ok=True)
    pngs, report = [], []
    with sync_playwright() as pw:
        browser = launch(pw)
        ctx = browser.new_context(viewport={"width": 1080, "height": 1920}, device_scale_factor=1)
        ctx.add_init_script("window.__EXPORT = true;")
        for pf in pages:
            pg = ctx.new_page()
            errs = []
            pg.on("pageerror", lambda e, errs=errs: errs.append(str(e)))
            pg.goto(f"http://127.0.0.1:{port}/pages/{pf.name}")
            try:
                pg.wait_for_function("window.__ready !== undefined", timeout=15000)
                meta = pg.evaluate("window.__ready")
            except Exception as e:  # noqa: BLE001
                print(f"[錯誤] {pf.name} 沒有呼叫 scene()，或 runtime.js 沒載入：{e}\n{errs}")
                pg.close()
                continue
            if errs:
                print(f"[警告] {pf.name} 的 JavaScript 錯誤：{errs}")
            if meta.get("fontErrors"):
                print(f"[警告] {pf.name} 字型載入失敗：{meta['fontErrors']}（檢查 fonts/ 資料夾）")
            W, H = int(meta["W"]), int(meta["H"])
            pg.set_viewport_size({"width": W, "height": H})
            stage = pg.locator("#stage")
            bg = css_color_to_hex(pg.evaluate("getComputedStyle(document.getElementById('stage')).backgroundColor"))

            t_png = a.at if a.at is not None else meta["cover"]
            pg.evaluate("t => window.seek(t)", t_png)
            png = out / f"{pf.stem}.png"
            stage.screenshot(path=str(png), type="png", caret="hide")
            pngs.append(png)
            if bg == "#000000":   # 背景是漸層或透明時，改用 PNG 上緣的平均色當 Reels 補邊色
                from PIL import Image
                row = Image.open(png).convert("RGB").resize((64, 1), box=(0, 0, W, 4))
                px = [row.getpixel((x, 0)) for x in range(row.width)]
                bg = "#{:02X}{:02X}{:02X}".format(*(sum(c[i] for c in px) // len(px) for i in range(3)))
            line = f"{pf.stem}: PNG（{t_png:.2f}s）"

            if a.reels and H != 1920:
                from PIL import Image
                im = Image.open(png).convert("RGB")
                s = min(1080 / W, 1920 / H)
                im = im.resize((round(W * s), round(H * s)), Image.LANCZOS)
                canvas = Image.new("RGB", (1080, 1920), bg)
                canvas.paste(im, ((1080 - im.width) // 2, (1920 - im.height) // 2))
                canvas.save(out / f"{pf.stem}_reels.png")

            if a.mp4_all or (a.mp4 and meta.get("motion") == "animated"):
                fps = a.fps or int(meta.get("fps", 30))
                D = float(meta["duration"])
                n = round(D * fps) + (0 if meta.get("loop") else 1)   # 不循環的頁包含最後一格
                mp4 = out / f"{pf.stem}.mp4"
                cmd = ["ffmpeg", "-y", "-v", "error", "-f", "image2pipe", "-c:v", "png", "-r", str(fps), "-i", "-",
                       "-c:v", "libx264", "-preset", "veryfast", "-crf", str(a.crf),
                       "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(mp4)]
                ff = subprocess.Popen(cmd, stdin=subprocess.PIPE)
                t0 = time.time()
                for f in range(n):
                    pg.evaluate("t => window.seek(t)", f / fps)
                    ff.stdin.write(stage.screenshot(type="png", caret="hide"))
                ff.stdin.close()
                if ff.wait() != 0:
                    print(f"[錯誤] {pf.name} 的 MP4 輸出失敗")
                else:
                    line += f"、MP4（{n} 格、{fps}fps、{time.time() - t0:.0f} 秒）"
                    if a.reels and H != 1920:
                        subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(mp4), "-vf",
                                        f"scale=1080:-2,pad=1080:1920:(ow-iw)/2:(oh-ih)/2:color={bg}",
                                        "-c:v", "libx264", "-preset", "veryfast", "-crf", str(a.crf),
                                        "-pix_fmt", "yuv420p", "-movflags", "+faststart",
                                        str(out / f"{pf.stem}_reels.mp4")], check=False)
            report.append(line)
            pg.close()
        browser.close()
    httpd.shutdown()

    sheet = overview(pngs, out)
    print("\n".join(report))
    if sheet:
        print(f"總覽圖：{sheet}")
    print(f"輸出資料夾：{out}")


if __name__ == "__main__":
    main()
