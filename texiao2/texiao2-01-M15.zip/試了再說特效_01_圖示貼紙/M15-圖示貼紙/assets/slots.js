/*
 * 影片特效庫：素材格子工具（每個模板的 assets/ 都放一份，跟 runtime.js 一起載入）
 *
 * 格子 = 設定區裡的一個物件：
 *   { id, 種類, 檔案, 標籤, x, y, w, h, 出現, 結束, ... }
 *   種類：'人物去背' | '照片' | '影片' | '截圖' | '文字'
 *   檔案：空字串 → 畫佔位；有路徑 → 用真素材（路徑相對於 pages/，例如 '../assets/我的照片.jpg'）
 *   出現／結束：秒數（結束不寫 = 到片尾）
 *   人物去背另外有 headX, headY：頭的中心點（畫布座標 px）
 *   影片另外有 影片起點（從素材第幾秒開始放，預設 0）、循環（true/false）
 *   文字另外有 字、字級、字色、字型、對齊
 *
 * 用法（在頁面的 scene 裡）：
 *   const g = Slots.build(stage, 格子)       // 建 DOM，回傳 { el, slot }
 *   Slots.sync(t)                             // 每格呼叫：處理 出現/結束、影片佔位的時間碼
 *   Slots.wrapSeek()                          // scene() 之後呼叫一次：讓影片 currentTime 跟著 t 走，等畫面到位才截圖
 * 規則：不用 Math.random / Date.now，同一個 t 永遠畫出同一格。
 */
(function () {
  const S = { all: [], videos: [] };
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  /** 佔位：淺灰底＋細虛線框＋中間寫要補什麼 */
  function placeholder(label, sub) {
    return `<div class="ph"><div class="ph-label">${esc(label)}</div>${sub ? `<div class="ph-sub">${esc(sub)}</div>` : ''}</div>`;
  }

  /** 人物佔位：灰色剪影（頭＋肩），頭的中心對準 headX, headY */
  function silhouette(slot) {
    const hx = (slot.headX ?? slot.x + slot.w / 2) - slot.x;
    const hy = (slot.headY ?? slot.y + slot.h * 0.35) - slot.y;
    const r = slot.頭半徑 || 180;                       // 頭的半徑（高，px）
    const sw = r * 3.7, top = hy + r * 1.3;             // 肩寬、肩膀上緣
    const body = `M ${hx - r * 0.42} ${hy + r * 0.7} L ${hx + r * 0.42} ${hy + r * 0.7} L ${hx + r * 0.5} ${top - r * 0.1}
      C ${hx + sw * 0.3} ${top}, ${hx + sw / 2} ${top + r * 0.25}, ${hx + sw / 2} ${top + r * 1.2}
      L ${hx + sw / 2 + r * 0.1} ${slot.h} L ${hx - sw / 2 - r * 0.1} ${slot.h} L ${hx - sw / 2} ${top + r * 1.2}
      C ${hx - sw / 2} ${top + r * 0.25}, ${hx - sw * 0.3} ${top}, ${hx - r * 0.5} ${top - r * 0.1} Z`;
    return `<svg class="sil" width="${slot.w}" height="${slot.h}" viewBox="0 0 ${slot.w} ${slot.h}">
      <path d="${body}" fill="#A9A9A9" stroke="#7A7A7A" stroke-width="3" stroke-dasharray="12 8"/>
      <ellipse cx="${hx}" cy="${hy}" rx="${r * 0.78}" ry="${r}" fill="#A9A9A9" stroke="#7A7A7A" stroke-width="3" stroke-dasharray="12 8"/>
      <g stroke="#E3301C" stroke-width="4"><line x1="${hx - 22}" y1="${hy}" x2="${hx + 22}" y2="${hy}"/><line x1="${hx}" y1="${hy - 22}" x2="${hx}" y2="${hy + 22}"/></g>
      <text x="${hx + 30}" y="${hy - 12}" fill="#E3301C" font-size="26" font-family="LINE Seed TW">頭位置 headX, headY</text>
      <text x="${hx}" y="${top + r * 1.6}" text-anchor="middle" fill="#3A3A3A" font-size="56" font-family="LINE Seed TW">${esc(slot.標籤 || '人物（去背）')}</text>
      <text x="${hx}" y="${top + r * 1.6 + 56}" text-anchor="middle" fill="#555" font-size="30" font-family="LINE Seed TW">透明 PNG・1080×1920</text>
    </svg>`;
  }

  S.build = function (stage, slot) {
    const el = document.createElement('div');
    el.className = 'slot slot-' + slot.種類;
    el.dataset.id = slot.id;
    Object.assign(el.style, { left: slot.x + 'px', top: slot.y + 'px', width: slot.w + 'px', height: slot.h + 'px' });
    const k = slot.種類, f = slot.檔案;
    if (k === '影片') {
      if (f) {
        const v = document.createElement('video');
        Object.assign(v, { muted: true, playsInline: true, preload: 'auto' });
        // 先整支讀進記憶體再播：export.py 的本機伺服器不支援分段讀取，直接給網址會跳不到指定秒數
        fetch(f).then((r) => r.blob()).then((b) => { v.src = URL.createObjectURL(b); });
        // 畫面用 canvas 顯示：seek 完把那一格畫上去（直接顯示 <video> 截圖時會慢 3 格）
        const c = document.createElement('canvas');
        c.width = slot.w; c.height = slot.h; c.className = 'fill';
        c.getContext('2d', { willReadFrequently: false });
        el.appendChild(c);
        S.videos.push({ v, slot, c });
      } else {
        el.innerHTML = placeholder(slot.標籤 || '影片', '影片 mp4・1080×1920') + '<div class="ph-tc">00:00.0</div>';
      }
    } else if (k === '人物去背') {
      el.innerHTML = f ? `<img class="fill" src="${esc(f)}" style="object-fit:fill">` : silhouette(slot);
      if (!f) el.classList.add('is-ph');
    } else if (k === '照片' || k === '截圖') {
      el.innerHTML = f ? `<img class="fill" src="${esc(f)}" style="object-fit:cover">` : placeholder(slot.標籤 || k, slot.說明 || '');
    } else if (k === '文字') {
      el.innerHTML = `<div class="txt">${esc(slot.字 || '')}</div>`;
      Object.assign(el.firstChild.style, { fontSize: (slot.字級 || 72) + 'px', color: slot.字色 || '#111',
        fontFamily: slot.字型 || 'Mantou Sans', textAlign: slot.對齊 || 'center' });
    }
    if (!f && k !== '文字') el.classList.add('is-ph');
    stage.appendChild(el);
    const g = { el, slot };
    S.all.push(g);
    return g;
  };

  /** 每格呼叫：出現/結束、影片佔位的時間碼（自管的格子由頁面自己控制顯示） */
  S.sync = function (t) {
    for (const { el, slot } of S.all) {
      if (!slot.自管) {
        const on = t >= (slot.出現 || 0) && (slot.結束 === undefined || t < slot.結束);
        el.style.visibility = on ? 'visible' : 'hidden';
      }
      const tc = el.querySelector('.ph-tc');
      if (tc) {
        const s = Math.max(0, t - (slot.出現 || 0) + (slot.影片起點 || 0));
        tc.textContent = `${String(Math.floor(s / 60)).padStart(2, '0')}:${(s % 60).toFixed(1).padStart(4, '0')}`;
      }
    }
    S._t = t;
  };

  function videoTime(v, slot, t) {
    // 多加半格：停在那一格的正中間，避免瀏覽器顯示前一格
    let s = t - (slot.出現 || 0) + (slot.影片起點 || 0) + 0.5 / FPS();
    const d = v.duration || 0;
    if (d > 0) s = slot.循環 ? ((s % d) + d) % d : Math.min(s, d - 0.5 / FPS());
    return Math.max(0, s);
  }
  const FPS = () => (window.__meta && window.__meta.fps) || 30;

  function paint(c, v, slot) {
    const ctx = c.getContext('2d');
    // 跟 object-fit: cover 一樣：等比放大填滿格子，多的裁掉
    const vw = v.videoWidth, vh = v.videoHeight;
    if (!vw) return;
    const k = Math.max(c.width / vw, c.height / vh), dw = vw * k, dh = vh * k;
    ctx.drawImage(v, (c.width - dw) / 2, (c.height - dh) / 2, dw, dh);
  }

  // 把影片停到 target 秒：設定 currentTime 後輪詢，直到瀏覽器說「到了、可以畫」為止
  function seekVideo(v, target) {
    return new Promise((res, rej) => {
      let asked = false, n = 0;
      const tick = () => {
        n++;
        if (v.readyState >= 1 && !asked) { v.currentTime = target; asked = true; }
        // 最後一格：影片播到底（ended）時 Chrome 會把 currentTime 跳成 duration，差半格，以前會卡 60 秒報錯（2026-11-23 M01）
        const atEnd = v.ended && v.duration && target >= v.duration - 1 / FPS();
        const ok = asked && !v.seeking && v.readyState >= 2 && (atEnd || Math.abs(v.currentTime - Math.min(target, v.duration || target)) < 0.002);
        if (ok) return res();
        // 等約 60 秒還沒到位就報錯，讓出檔停下來；以前是照樣截圖，電腦很忙時會出整段黑畫面（2026-11-22 M16）
        if (n > 12000) return rej(new Error('影片格子跳不到 ' + target.toFixed(3) + ' 秒，出檔停止，再出一次'));
        setTimeout(tick, 5);
      };
      tick();
    });
  }

  /** 讓 window.seek(t) 也把影片停到對的那一格，回傳 Promise（export.py 會等它） */
  S.wrapSeek = function () {
    const orig = window.seek;
    window.seek = (t) => {
      const tt = orig(t);
      if (!S.videos.length) return tt;
      return Promise.all(S.videos.map((o) => (o.q = (o.q || Promise.resolve())
        .then(() => seekVideo(o.v, videoTime(o.v, o.slot, tt))).then(() => paint(o.c, o.v, o.slot))))).then(() => tt);
    };
    // 預覽時影片第一格也到位
    if (S.videos.length && S._t !== undefined) window.seek(S._t);
  };

  window.Slots = S;
})();
