/*
 * carousel-motion runtime
 * 一頁 = 一個 #stage。畫面上所有東西都由時間 t（秒）算出：window.seek(t) 會把畫面停在那一格。
 * 規則：不用 CSS animation / transition、不用 Math.random / Date.now；要隨機感用 R.hrand()。
 * #stage 的 data-* 屬性：
 *   data-w / data-h     畫布尺寸（預設 1080 × 1350，4:5）
 *   data-duration       片長秒數
 *   data-loop           "1" 無縫循環（t 取餘數）；"0" 播一次停在結尾
 *   data-cover          匯出靜態 PNG 用哪一秒（預設：循環頁取一半，不循環取結尾）
 *   data-motion         "animated" 要出 MP4；"static" 只出 PNG
 *   data-fps            影格率（預設 30）
 * 預覽：直接用瀏覽器開（建議透過 export.py --serve），會自動播放；網址加 ?t=1.2 可停在 1.2 秒。
 */
(function () {
  const R = {};
  R.clamp = (x, a = 0, b = 1) => Math.min(Math.max(x, a), b);
  R.lerp = (a, b, p) => a + (b - a) * p;
  R.prog = (t, start, dur) => (dur <= 0 ? (t >= start ? 1 : 0) : R.clamp((t - start) / dur));
  R.easeOut = (p, k = 3) => 1 - Math.pow(1 - p, k);
  R.easeIn = (p, k = 3) => Math.pow(p, k);
  R.easeInOut = (p) => (p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2);
  R.backOut = (p, s = 1.70158) => { p -= 1; return p * p * ((s + 1) * p + s) + 1; };
  R.spring = (p, bounces = 2, decay = 5) => 1 - Math.exp(-decay * p) * Math.cos(bounces * 2 * Math.PI * p);
  R.wrap = (t, D) => ((t % D) + D) % D;
  /** 固定亂數：同樣的 keys 永遠得到同一個 0–1 的值 */
  R.hrand = (...keys) => {
    let h = 2166136261 >>> 0;
    const s = keys.join('|');
    for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
    h ^= h >>> 13; h = Math.imul(h, 0x5bd1e995); h ^= h >>> 15;
    return (h >>> 0) / 4294967296;
  };
  R.$ = (sel, root = document) => root.querySelector(sel);
  R.$$ = (sel, root = document) => [...root.querySelectorAll(sel)];
  R.css = (el, styles) => Object.assign(el.style, styles);
  R.esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  /** 把元素的文字拆成每字一個 <span class="ch">（逐字動畫用） */
  R.splitChars = (el, text = el.textContent) => {
    el.textContent = '';
    return [...text].map((c) => {
      const s = document.createElement('span');
      s.className = 'ch';
      s.textContent = c === ' ' ? ' ' : c;
      el.appendChild(s);
      return s;
    });
  };
  /** 標記語法：[字] = 強調色字，{字} = 螢光筆底。回傳 HTML，每個字一個 span */
  R.markup = (line) => {
    let out = '', key = false, hl = false;
    for (const c of [...line]) {
      if (c === '[') { key = true; continue; }
      if (c === ']') { key = false; continue; }
      if (c === '{') { hl = true; out += '<span class="hl"><i class="marker"></i>'; continue; }
      if (c === '}') { hl = false; out += '</span>'; continue; }
      out += `<span class="ch${key ? ' key' : ''}">${c === ' ' ? '&nbsp;' : R.esc(c)}</span>`;
    }
    return out;
  };
  /** 頁尾：左邊帳號、右邊頁碼 */
  R.folio = (left, right, dark = false) => {
    const f = document.createElement('div');
    f.className = 'folio' + (dark ? ' on-dark' : '');
    f.innerHTML = `<span>${R.esc(left || '')}</span><span>${R.esc(right || '')}</span>`;
    document.getElementById('stage').appendChild(f);
    return f;
  };
  /** 元素相對 #stage 的位置（不受預覽縮放影響） */
  R.pos = (el) => {
    let x = 0, y = 0, n = el;
    const stage = document.getElementById('stage');
    while (n && n !== stage) { x += n.offsetLeft; y += n.offsetTop; n = n.offsetParent; }
    return { x, y, w: el.offsetWidth, h: el.offsetHeight, cx: x + el.offsetWidth / 2, cy: y + el.offsetHeight / 2 };
  };
  window.R = R;

  const stage = document.getElementById('stage');
  const W = +(stage.dataset.w || 1080), H = +(stage.dataset.h || 1350);
  const root = document.documentElement.style;
  root.setProperty('--W', W + 'px');
  root.setProperty('--H', H + 'px');
  root.setProperty('--u', W / 100 + 'px');
  root.setProperty('--v', H / 100 + 'px');

  let resolveReady;
  window.__ready = new Promise((r) => (resolveReady = r));

  /** 註冊這一頁的畫面函式：render(t, D) */
  window.scene = function (render, setup) {
    const D = +(stage.dataset.duration || 4);
    const loop = stage.dataset.loop === '1';
    const cover = stage.dataset.cover !== undefined ? +stage.dataset.cover : loop ? D / 2 : D;
    const meta = { W, H, duration: D, loop, cover, motion: stage.dataset.motion || 'animated',
                   fps: +(stage.dataset.fps || 30), title: document.title };
    window.__meta = meta;
    window.seek = (t) => {
      const tt = loop ? R.wrap(t, D) : R.clamp(t, 0, D);
      render(tt, D);
      return tt;
    };
    // 先把 CSS 宣告的字型全部載入，再做需要量尺寸的 setup，第一格才不會是系統預設字
    const faces = [...document.fonts];
    Promise.all(faces.map((f) => (f.status === 'unloaded' ? f.load() : f.loaded).catch(() => null)))
      .then(() => document.fonts.ready)
      .then(() => Promise.all(R.$$('img').map((im) => (im.complete ? im.decode() : new Promise((r) => { im.onload = im.onerror = r; })).catch(() => null))))
      .then(() => {
        if (setup) setup();
        meta.fontErrors = [...document.fonts].filter((f) => f.status === 'error').map((f) => f.family);
        const q = new URLSearchParams(location.search).get('t');
        window.seek(q !== null ? +q : cover);
        resolveReady(meta);
        if (!window.__EXPORT && q === null) play(D, loop);
        if (!window.__EXPORT) fit();
      });
  };

  function fit() {
    const s = Math.min(innerWidth / W, innerHeight / H, 1);
    stage.style.transformOrigin = 'top left';
    stage.style.transform = `scale(${s})`;
    document.body.style.width = W * s + 'px';
    document.body.style.height = H * s + 'px';
    window.addEventListener('resize', fit, { once: true });
  }

  function play(D, loop) {
    const t0 = performance.now();
    const tick = (now) => {
      const t = (now - t0) / 1000;
      window.seek(loop ? t : t % (D + 1.2)); // 不循環的頁：播完停 1.2 秒再重播
      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }
})();
