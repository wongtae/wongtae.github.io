/*
 * M02–M06 共用小工具（不是 _共用/ 的檔，是這幾個模板自己帶的一份；改了要複製到 M02–M06 的 assets/）
 * - MFX.版型(設定)：'全螢幕' 或 '上下分割'，調整背景影片格子的位置，回傳 { split, top, bottom }
 * - MFX.貼紙字(行陣列)：縮圖同一套「貼紙雙描邊」：字＋墨黑描邊＋外圈白邊＋淡陰影
 *   會縮放的話，字型載入後呼叫一次 wrap.畫成圖()，換成 canvas 圖片（出兩次才會逐格一樣）
 * - MFX.bezier(x1,y1,x2,y2)：cubic-bezier 緩動
 * - MFX.勾()：紅筆手繪勾的 SVG（用 stroke-dashoffset 畫出來）
 * - MFX.spring(p, k, w)、MFX.彈：彈簧緩動（2026-11-23 精緻化，數值同 README「讓動畫更生動的做法」）
 * - MFX.浮動(t, key, i)、MFX.呼吸(t, since)：停住後不要整格靜止
 * - MFX.紙卡底(el, w, h, opts)：卡片的紙底＋墨線＋陰影先畫成一張 canvas（不用 CSS box-shadow）
 * 規則同 runtime.js：不用 CSS animation、transition、Math.random、Date.now。
 */
(function () {
  const M = {};
  M.色 = { 紙: '#F4F1EA', 墨: '#111111', 紅: '#E3301C', 黃: '#FFDD3C', 灰: '#8A8A8A', 白: '#FFFFFF' };

  /** 版型：全螢幕 = 背景影片 1080×1920；上下分割 = 上面紙白放特效、下面放影片 */
  M.版型 = function (設定) {
    const P = 設定.參數;
    const bg = 設定.格子.find((s) => s.id === '背景');
    const split = P.版型 === '上下分割';
    const y = P.分割線 || 960;
    if (split && bg) Object.assign(bg, { x: 0, y, w: 1080, h: 1920 - y });
    return { split, top: split ? { x: 0, y: 0, w: 1080, h: y } : { x: 0, y: 0, w: 1080, h: 1920 }, bottomY: split ? y : 1920 };
  };

  /**
   * 貼紙雙描邊字
   * lines: [{ 字: '留言「剪片」', 字級: 120, 色: '#FFDD3C', 重點: '剪片', 重點色: '#E3301C' }, …]
   * opts: { 墨邊: 10, 白邊: 22, 行距: 1.1, 對齊: 'center' }
   */
  M.貼紙字 = function (lines, opts = {}) {
    const ink = opts.墨邊 ?? 10, white = opts.白邊 ?? 22;
    const wrap = document.createElement('div');
    wrap.className = 'mfx-sticker';
    wrap.style.cssText = `position:absolute;display:flex;flex-direction:column;align-items:${opts.對齊 === 'left' ? 'flex-start' : 'center'};`;
    for (const L of lines) {
      const size = L.字級 || 100;
      const row = document.createElement('div');
      row.style.cssText = `display:grid;line-height:${opts.行距 || 1.12};font:900 ${size}px 'LINE Seed TW';letter-spacing:0.02em;white-space:pre;`;
      const html = (color, kcolor) => {
        const s = R.esc(L.字);
        if (!L.重點) return `<span style="color:${color}">${s}</span>`;
        const k = R.esc(L.重點);
        return s.split(k).map((p) => `<span style="color:${color}">${p}</span>`).join(`<span style="color:${kcolor}">${k}</span>`);
      };
      const sw = (L.縮邊 ?? 1) * (size / 100);
      const layers = [
        // 淡陰影：往下錯開的一層半透明黑（不用 filter 模糊：模糊在縮放時每次出檔會差幾個色階）
        `-webkit-text-stroke:${(ink + white) * 2 * sw}px #000;color:#000;opacity:.2;transform:translateY(${7 * sw}px);`,
        // 外圈白邊
        `-webkit-text-stroke:${(ink + white) * 2 * sw}px #fff;color:#fff;`,
        // 墨黑描邊
        `-webkit-text-stroke:${ink * 2 * sw}px ${M.色.墨};color:${M.色.墨};`,
        // 字本身
        ``,
      ];
      layers.forEach((css, i) => {
        const d = document.createElement('div');
        d.style.cssText = `grid-area:1/1;position:relative;z-index:${i};${css}`;
        d.innerHTML = i < layers.length - 1 ? `<span>${R.esc(L.字)}</span>` : html(L.色 || M.色.黃, L.重點色 || M.色.紅);
        row.appendChild(d);
      });
      row._L = L; row._sw = sw;
      wrap.appendChild(row);
    }
    /**
     * 畫成圖（2026-11-23）：把每一行換成 canvas 畫好的圖片。要在字型載入後呼叫（例如第一次 scene 時）。
     * 為什麼：CSS 粗描邊放大縮小時，每次出檔會有幾個像素差 1 個色階；canvas 畫好再縮放就每次一樣（M20 同做法）。
     * 呼叫幾次都可以，只畫第一次。
     */
    wrap.畫成圖 = function () {
      if (wrap.dataset.raster) return;
      wrap.dataset.raster = '1';
      const HQ = 2;
      [...wrap.children].forEach((row) => {
        const L = row._L, sw = row._sw, size = L.字級 || 100;
        const rw = row.offsetWidth, rh = row.offsetHeight;
        const m = Math.ceil((ink + white) * sw + 12 * sw);
        const c = document.createElement('canvas');
        c.width = Math.ceil((rw + 2 * m) * HQ); c.height = Math.ceil((rh + 2 * m) * HQ);
        c.style.cssText = `position:absolute;left:${-m}px;top:${-m}px;width:${c.width / HQ}px;height:${c.height / HQ}px;`;
        const x = c.getContext('2d');
        x.scale(HQ, HQ);
        x.font = `900 ${size}px 'LINE Seed TW'`;
        x.lineJoin = 'round'; x.miterLimit = 2; x.textBaseline = 'alphabetic';
        const ls = 0.02 * size;
        const mt = x.measureText('國');
        const asc = mt.fontBoundingBoxAscent, desc = mt.fontBoundingBoxDescent;
        const baseY = m + (rh - (asc + desc)) / 2 + asc;
        const chars = [...L.字];
        const kws = L.重點 ? [...L.重點] : [];
        // 每個字的顏色：落在「重點」字串裡的用重點色
        const col = chars.map(() => L.色 || M.色.黃);
        if (kws.length) for (let i = 0; i + kws.length <= chars.length; i++) {
          if (chars.slice(i, i + kws.length).join('') === L.重點) { for (let j = 0; j < kws.length; j++) col[i + j] = L.重點色 || M.色.紅; i += kws.length - 1; }
        }
        const xs = []; let cx = m;
        chars.forEach((ch) => { xs.push(cx); cx += x.measureText(ch).width + ls; });
        const pass = (fn) => chars.forEach((ch, i) => fn(ch, xs[i]));
        const ow = (ink + white) * 2 * sw;
        x.save(); x.globalAlpha = 0.2; x.strokeStyle = '#000'; x.fillStyle = '#000'; x.lineWidth = ow;
        pass((ch, X) => { x.strokeText(ch, X, baseY + 7 * sw); x.fillText(ch, X, baseY + 7 * sw); }); x.restore();
        x.strokeStyle = '#fff'; x.fillStyle = '#fff'; x.lineWidth = ow;
        pass((ch, X) => { x.strokeText(ch, X, baseY); x.fillText(ch, X, baseY); });
        x.strokeStyle = M.色.墨; x.lineWidth = ink * 2 * sw;
        pass((ch, X) => x.strokeText(ch, X, baseY));
        chars.forEach((ch, i) => { x.fillStyle = col[i]; x.fillText(ch, xs[i], baseY); });
        Object.assign(row.style, { position: 'relative', display: 'block', width: rw + 'px', height: rh + 'px' });
        row.replaceChildren(c);
      });
    };
    return wrap;
  };

  /** cubic-bezier(x1,y1,x2,y2)：回傳 p(0–1) → 進度 */
  M.bezier = function (x1, y1, x2, y2) {
    const bx = (u) => 3 * x1 * u * (1 - u) ** 2 + 3 * x2 * u * u * (1 - u) + u ** 3;
    const by = (u) => 3 * y1 * u * (1 - u) ** 2 + 3 * y2 * u * u * (1 - u) + u ** 3;
    return (p) => {
      if (p <= 0) return 0;
      if (p >= 1) return 1;
      let lo = 0, hi = 1;
      for (let i = 0; i < 40; i++) { const m = (lo + hi) / 2; if (bx(m) < p) lo = m; else hi = m; }
      return by((lo + hi) / 2);
    };
  };

  /** 紅筆手繪勾：回傳 { svg, set(p) }，p = 0–1 畫出來的比例 */
  M.勾 = function (size = 64, color = M.色.紅, width = 9) {
    const ns = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(ns, 'svg');
    svg.setAttribute('viewBox', '0 0 64 64');
    svg.setAttribute('width', size); svg.setAttribute('height', size);
    svg.style.overflow = 'visible';
    const path = document.createElementNS(ns, 'path');
    // 有點歪的手寫勾：短邊往下、長邊往右上甩出去
    path.setAttribute('d', 'M 6 34 C 12 38, 17 44, 23 53 C 30 38, 42 20, 62 4');
    Object.entries({ fill: 'none', stroke: color, 'stroke-width': width, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' })
      .forEach(([k, v]) => path.setAttribute(k, v));
    svg.appendChild(path);
    let len = 0;
    const set = (p) => {
      if (!len) len = path.getTotalLength() || 90;
      path.setAttribute('stroke-dasharray', len);
      path.setAttribute('stroke-dashoffset', (len * (1 - R.clamp(p))).toFixed(2));
      svg.style.visibility = p > 0 ? 'visible' : 'hidden';
    };
    return { svg, set };
  };

  /* ---- 2026-11-23 精緻化：手感工具 ---- */
  /** 彈簧：0→1，先超過再回來；k 越大停得越快，w 越大彈越多下。保證 p=1 剛好 = 1 */
  M.spring = function (p, k = 6.5, w = 2.4) {
    if (p <= 0) return 0; if (p >= 1) return 1;
    const raw = (q) => 1 - Math.exp(-k * q) * Math.cos(w * Math.PI * q);
    return raw(p) + (1 - raw(1)) * p;
  };
  /** 常用三組：進場（超出約 10%）、落定、多晃一下 */
  M.彈 = {
    進場: (p) => M.spring(p, 7, 3),
    落定: (p) => M.spring(p, 6.5, 2.4),
    多晃: (p) => M.spring(p, 5, 3),
  };
  /** 飄浮：回傳 { y, r }，上下 ±amp px（週期 2.4 秒）、角度 ±deg（週期 3.1 秒），相位每個元素不同 */
  M.浮動 = function (t, key, i = 0, amp = 7, deg = 1.6) {
    const TAU = Math.PI * 2;
    return {
      y: amp * Math.sin(TAU * t / 2.4 + R.hrand(key, 'y', i) * TAU),
      r: deg * Math.sin(TAU * t / 3.1 + R.hrand(key, 'r', i) * TAU),
    };
  };
  /** 停住後的小呼吸：回傳縮放倍數（±0.6%，週期 2.2 秒），since 之前 = 1，之後 0.4 秒內淡入 */
  M.呼吸 = function (t, since, amp = 0.006, T = 2.2) {
    if (t <= since) return 1;
    const fade = R.clamp((t - since) / 0.4);
    return 1 + amp * fade * Math.sin(Math.PI * 2 * (t - since) / T);
  };

  /**
   * 紙卡底：把卡片的紙底、墨線、陰影先畫成一張 canvas 放在 el 最底層（el 本身改成透明）。
   * 為什麼：CSS box-shadow／drop-shadow 跟著縮放旋轉時，每次出檔會差幾個色階；canvas 畫好再轉就穩。
   * el 要先有 left/top/width/height（w、h 傳一樣的數字）。原本的 3px 墨線位置保留成透明邊，裡面的東西不會位移。
   * opts: { 圓角: 28, 底色: 紙, 線: 3, 線色: 墨, 陰影: 0.26, 模糊: 26, 下移: 10 }
   */
  M.紙卡底 = function (el, w, h, opts = {}) {
    const r = opts.圓角 ?? 28, line = opts.線 ?? 3, SM = 56, HQ = 2;
    const fill = opts.底色 || M.色.紙, ink = opts.線色 || M.色.墨;
    const c = document.createElement('canvas');
    c.width = (w + SM * 2) * HQ; c.height = (h + SM * 2) * HQ;
    c.style.cssText = `position:absolute;left:${-SM - line}px;top:${-SM - line}px;width:${w + SM * 2}px;height:${h + SM * 2}px;pointer-events:none;`;
    const x = c.getContext('2d');
    x.scale(HQ, HQ);
    if (opts.陰影 !== 0) {
      x.save();
      x.shadowColor = `rgba(18,16,14,${opts.陰影 ?? 0.26})`; x.shadowBlur = (opts.模糊 ?? 26) * HQ;
      x.shadowOffsetX = 10000 * HQ; x.shadowOffsetY = (opts.下移 ?? 10) * HQ;
      x.fillStyle = '#000'; x.beginPath(); x.roundRect(SM - 10000, SM, w, h, r); x.fill();
      x.restore();
    }
    x.fillStyle = line ? ink : fill; x.beginPath(); x.roundRect(SM, SM, w, h, r); x.fill();
    if (line) { x.fillStyle = fill; x.beginPath(); x.roundRect(SM + line, SM + line, w - 2 * line, h - 2 * line, Math.max(0, r - line)); x.fill(); }
    Object.assign(el.style, { background: 'transparent', boxShadow: 'none', borderColor: 'transparent' });
    el.insertBefore(c, el.firstChild);
    return c;
  };

  /** 建一個絕對定位的 div */
  M.div = function (parent, css = '', html = '') {
    const d = document.createElement('div');
    d.style.cssText = 'position:absolute;box-sizing:border-box;' + css;
    if (html) d.innerHTML = html;
    parent.appendChild(d);
    return d;
  };

  window.MFX = M;
})();
