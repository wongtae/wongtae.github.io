/* 2026-11-23：圈、箭頭、底線改成粗細穩定、不抖的筆畫（stroke 的 clean 參數），Tae 說原本的圈不規則很醜。
   影片特效庫複本（2026-11-22）：viewBox 改成跟著 #stage 的 data-w/data-h（原本寫死 1080×1350），圖層高度可用 window.HAND_Z 改。
   手繪紅筆 v2：用 perfect-freehand（Steve Ruiz，MIT）把中心線變成有筆壓粗細的筆畫。
   每一筆是填色的外框，不是固定粗細的線；畫到一半時只算前面那段的筆畫，所以可以停在任一格。
   筆觸由 window.HAND_STYLE 決定：'mix'（預設）大的用麥克筆、細節用原子筆；'marker'、'pen'、'brush' 全部用同一種。
   mix 的規則：被圈的東西寬 300px 以上、箭頭長 320px 以上、底線寬 220px 以上用麥克筆；小叉、打勾和比較小的標註用原子筆。
   每個函式最後一個參數可以指定 'marker' 或 'pen' 蓋過自動判斷。
   用法跟 v1 一樣：setup 裡建立，render 裡 H.draw(mark, p)。 */
(function () {
  const NS = 'http://www.w3.org/2000/svg';
  const STYLES = {
    marker: { size: 15, thinning: 0.35, smoothing: 0.6, streamline: 0.45, start: { taper: 6 }, end: { taper: 22 }, opacity: 0.92, passes: 1 },
    pen:    { size: 5.5, thinning: 0.55, smoothing: 0.55, streamline: 0.35, start: { taper: 10 }, end: { taper: 30 }, opacity: 1, passes: 2 },
    brush:  { size: 22, thinning: 0.78, smoothing: 0.65, streamline: 0.5, start: { taper: 26 }, end: { taper: 90 }, opacity: 0.9, passes: 1 },
  };
  const H = {};
  let svg;
  const TOOL = (t, auto) => (t === 'marker' || t === 'pen' ? t : auto);
  const pick = (want) => { const g = window.HAND_STYLE || 'mix'; return STYLES[g === 'mix' ? want : g] || STYLES.marker; };
  const r = (seed, k) => R.hrand(seed, k) * 2 - 1;

  H.layer = () => {
    if (!svg) {
      svg = document.createElementNS(NS, 'svg');
      svg.setAttribute('class', 'ink2');
      const st = document.getElementById('stage'); svg.setAttribute('viewBox', `0 0 ${st.dataset.w || 1080} ${st.dataset.h || 1350}`);
      R.css(svg, { position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none', zIndex: window.HAND_Z || 25, overflow: 'visible' });
      document.getElementById('stage').appendChild(svg);
    }
    return svg;
  };

  // 中心線取樣：每 5px 一點，筆壓「下筆重、中間穩、收筆輕」
  function resample(pts, seed, clean) {
    const out = [];
    for (let i = 0; i < pts.length - 1; i++) {
      const [x1, y1] = pts[i], [x2, y2] = pts[i + 1];
      const n = Math.max(1, Math.ceil(Math.hypot(x2 - x1, y2 - y1) / 5));
      for (let k = 0; k < n; k++) out.push([x1 + (x2 - x1) * k / n, y1 + (y2 - y1) * k / n]);
    }
    out.push(pts[pts.length - 1]);
    const N = out.length;
    return out.map(([x, y], i) => {
      const u = i / (N - 1);
      const pr = clean ? 0.78 : 0.5 + 0.35 * Math.sin(Math.PI * Math.min(1, u * 1.15)) + r(seed, 'p' + (i >> 3)) * 0.05;
      return [x, y, R.clamp(pr, 0.2, 1)];
    });
  }

  // 平滑曲線點（Catmull-Rom），讓手繪線條順
  function spline(ctrl, per = 8) {
    const out = [];
    for (let i = 0; i < ctrl.length - 1; i++) {
      const p0 = ctrl[i - 1] || ctrl[i], p1 = ctrl[i], p2 = ctrl[i + 1], p3 = ctrl[i + 2] || p2;
      for (let k = 0; k < per; k++) {
        const t = k / per, t2 = t * t, t3 = t2 * t;
        out.push([0, 1].map((j) => 0.5 * (2 * p1[j] + (-p0[j] + p2[j]) * t + (2 * p0[j] - 5 * p1[j] + 4 * p2[j] - p3[j]) * t2 + (-p0[j] + 3 * p1[j] - 3 * p2[j] + p3[j]) * t3)));
      }
    }
    out.push(ctrl[ctrl.length - 1]);
    return out;
  }

  function outline(points, opt, last) {
    const o = window.PF.getStroke(points, { ...opt, simulatePressure: false, last });
    if (o.length < 3) return '';
    let d = `M${o[0][0].toFixed(1)},${o[0][1].toFixed(1)} Q`;
    for (let i = 0; i < o.length; i++) {
      const [x0, y0] = o[i], [x1, y1] = o[(i + 1) % o.length];
      d += `${x0.toFixed(1)},${y0.toFixed(1)} ${((x0 + x1) / 2).toFixed(1)},${((y0 + y1) / 2).toFixed(1)} `;
    }
    return d + 'Z';
  }

  // 一筆（原子筆會疊兩次、稍微錯開，像來回描）
  function stroke(center, seed, k = 1, want = 'marker', clean = false) {
    const s = pick(want), items = [], opt = { ...s, size: s.size * k, ...(clean ? { thinning: 0.15, start: { taper: 14 }, end: { taper: 40 } } : {}) };
    for (let j = 0; j < (clean ? 1 : s.passes); j++) {
      const dx = j ? r(seed, 'dx') * 1.8 : 0, dy = j ? r(seed, 'dy') * 1.8 : 0;
      const pts = resample(center.map(([x, y]) => [x + dx, y + dy]), seed + j, clean);
      const el = document.createElementNS(NS, 'path');
      R.css(el, { fill: 'var(--red)', opacity: s.opacity });
      H.layer().appendChild(el);
      items.push({ pts, el, opt: j ? { ...opt, size: opt.size * 0.55 } : opt });
    }
    return [{ items, len: items[0].pts.length }];
  }

  /** 圈（2026-11-23 v3，Tae：圈起來不規則、蠻醜）：乾淨的橢圓，半徑固定不越繞越大、不加隨機抖動，
      粗細穩定（只有頭尾收細）；從左上起筆繞 1.06 圈，最後一小段微微往外，跟起筆處平行交疊 */
  H.circle = (box, seed = 'c', pad = 24, tool) => {
    const want = TOOL(tool, box.w >= 300 ? 'marker' : 'pen');
    const cx = box.x + box.w / 2, cy = box.y + box.h / 2, rx = box.w / 2 * 1.04 + pad, ry = box.h / 2 * 1.3 + pad * 0.8;   // 高度多放一點，長條框的四個角才不會凸出圈外
    const tilt = -0.035, a0 = -2.35, turns = 1.06, N = 120, pts = [];
    const lift = Math.min(10, ry * 0.12);   // 收尾那段往外偏多少 px
    for (let i = 0; i <= N; i++) {
      const u = i / N, a = a0 + u * Math.PI * 2 * turns;
      const out = u > 0.86 ? lift * Math.pow((u - 0.86) / 0.14, 2) : 0;
      const x = Math.cos(a) * (rx + out), y = Math.sin(a) * (ry + out);
      pts.push([cx + x * Math.cos(tilt) - y * Math.sin(tilt), cy + x * Math.sin(tilt) + y * Math.cos(tilt)]);
    }
    return stroke(pts, seed, want === 'marker' ? R.clamp(box.w / 420, 0.75, 1) : 1, want, true);
  };

  /** 方框（2026-11-23）：圓角矩形，線條直、粗細穩定；從上緣左側起筆，繞 1.04 圈，收尾微微往外跟起筆交疊。
      box 是要框的東西（不含邊距）；k 是筆畫粗細倍數 */
  H.box = (box, seed = 'b', pad = 24, k = 2.4, tool = 'pen') => {
    const x0 = box.x - pad, y0 = box.y - pad, w = box.w + pad * 2, h = box.h + pad * 2;
    const rad = Math.min(28, h / 4, w / 4), sw = w - 2 * rad, sh = h - 2 * rad, arc = Math.PI * rad / 2;
    const per = 2 * sw + 2 * sh + 4 * arc, start = Math.min(sw * 0.15, 60), total = per * 1.04, N = Math.ceil(total / 6), pts = [];
    const at = (s) => {   // 沿圓角矩形周長走 s px（順時針，0 = 上緣左端）
      s = ((s % per) + per) % per;
      const segs = [[sw, (d) => [x0 + rad + d, y0]], [arc, (d) => { const a = -Math.PI / 2 + d / rad; return [x0 + w - rad + rad * Math.cos(a), y0 + rad + rad * Math.sin(a)]; }],
        [sh, (d) => [x0 + w, y0 + rad + d]], [arc, (d) => { const a = d / rad; return [x0 + w - rad + rad * Math.cos(a), y0 + h - rad + rad * Math.sin(a)]; }],
        [sw, (d) => [x0 + w - rad - d, y0 + h]], [arc, (d) => { const a = Math.PI / 2 + d / rad; return [x0 + rad + rad * Math.cos(a), y0 + h - rad + rad * Math.sin(a)]; }],
        [sh, (d) => [x0, y0 + h - rad - d]], [arc, (d) => { const a = Math.PI + d / rad; return [x0 + rad + rad * Math.cos(a), y0 + rad + rad * Math.sin(a)]; }]];
      for (const [L, f] of segs) { if (s <= L) return f(s); s -= L; }
      return [x0 + rad, y0];
    };
    for (let i = 0; i <= N; i++) {
      const u = i / N, [x, y] = at(start + u * total);
      pts.push([x, y - (u > 0.9 ? 8 * Math.pow((u - 0.9) / 0.1, 2) : 0)]);
    }
    return stroke(pts, seed, k, tool, true);
  };

  /** 箭頭：彎曲的桿子一筆，箭頭用一筆 V 從一側經過尖端再到另一側 */
  H.arrow = (x1, y1, x2, y2, seed = 'a', bend = 0.22, tool) => {
    const want = TOOL(tool, Math.hypot(x2 - x1, y2 - y1) >= 320 ? 'marker' : 'pen');
    const mx = (x1 + x2) / 2, my = (y1 + y2) / 2, cxp = mx - (y2 - y1) * bend, cyp = my + (x2 - x1) * bend;
    const shaft = [];
    for (let i = 0; i <= 16; i++) { const t = i / 16, u = 1 - t; shaft.push([u * u * x1 + 2 * u * t * cxp + t * t * x2, u * u * y1 + 2 * u * t * cyp + t * t * y2]); }
    const ang = Math.atan2(y2 - cyp, x2 - cxp), L = 30;
    const head = [[x2 - L * Math.cos(ang - 0.55), y2 - L * Math.sin(ang - 0.55)], [x2, y2], [x2 - L * Math.cos(ang + 0.6), y2 - L * Math.sin(ang + 0.6)]];
    return [...stroke(shaft, seed, 1, want, true), ...stroke(head, seed + 'h', 0.9, want, true)];
  };

  /** 小叉：兩筆短線 */
  H.xmark = (x, y, s = 64, seed = 'x', tool = 'pen') => [
    ...stroke(spline([[x, y], [x + s * 0.5 + r(seed, 1) * 4, y + s * 0.52], [x + s, y + s]], 6), seed + 1, tool === 'pen' ? 0.95 : 0.7, tool),
    ...stroke(spline([[x + s * 0.96, y + s * 0.02], [x + s * 0.48, y + s * 0.5 + r(seed, 2) * 4], [x + s * 0.04, y + s * 0.98]], 6), seed + 2, tool === 'pen' ? 0.95 : 0.7, tool),
  ];

  /** 勾：短下筆、轉折、長上筆，一筆完成 */
  H.check = (x, y, s = 76, seed = 'v', tool = 'pen') => stroke(spline([[x, y + s * 0.48], [x + s * 0.18, y + s * 0.66], [x + s * 0.36, y + s * 0.92], [x + s * 0.62, y + s * 0.42], [x + s * 1.02, y - s * 0.04]], 7), seed, tool === 'pen' ? 0.95 : 0.75, tool);

  /** 底線：微微往上斜、尾巴勾一下 */
  H.under = (box, seed = 'u', tool) => {
    const want = TOOL(tool, box.w >= 220 ? 'marker' : 'pen');
    const y = box.y + box.h + 8, x0 = box.x - 6, x1 = box.x + box.w + 10;
    return stroke(spline([[x0, y + 4], [x0 + (x1 - x0) * 0.45, y + 1 + r(seed, 1) * 2], [x1, y - 6], [x1 - 18, y + 6]], 8), seed, 1, want, true);
  };

  /** 自由筆畫：給幾個控制點（星星、笑臉、閃光、波浪等塗鴉） */
  H.free = (ctrl, seed = 'f', k = 1, tool = 'pen') => stroke(spline(ctrl, 7), seed, k, tool);

  /** 依序畫出，p 從 0 到 1；原子筆的兩次描線同時進行 */
  H.draw = (mark, p) => {
    if (!mark) return;
    let done = p * mark.reduce((s, g) => s + g.len, 0);
    mark.forEach((g) => {
      const q = R.clamp(done / g.len);
      g.items.forEach((m) => {
        const n = Math.floor(q * m.pts.length);
        m.el.setAttribute('d', n < 2 ? '' : outline(m.pts.slice(0, n), m.opt, q >= 1));
      });
      done -= g.len;
    });
  };

  window.H = H;
})();
