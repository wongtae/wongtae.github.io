/*
 * M02–M06 共用小工具（不是 _共用/ 的檔，是這幾個模板自己帶的一份；改了要複製到 M02–M06 的 assets/）
 * - MFX.版型(設定)：'全螢幕' 或 '上下分割'，調整背景影片格子的位置，回傳 { split, top, bottom }
 * - MFX.貼紙字(行陣列)：縮圖同一套「貼紙雙描邊」：字＋墨黑描邊＋外圈白邊＋淡陰影
 * - MFX.bezier(x1,y1,x2,y2)：cubic-bezier 緩動
 * - MFX.勾()：紅筆手繪勾的 SVG（用 stroke-dashoffset 畫出來）
 * 規則同 runtime.js：不用 CSS animation、transition、Math.random、Date.now。
 */
(function () {
  const M = {};
  M.色 = { 紙: '#F4F1EA', 墨: '#111111', 紅: '#E3301C', 黃: '#FFDD3C', 灰: '#8A8A8A', 白: '#FFFFFF' };

  /** 版型：全螢幕 = 背景影片 1080×1920；上下分割 = 上面紙白放特效、下面放影片 */
  M.版型 = function (設定) {
    const P = 設定.參數;
    const bg = 設定.格子.find((s) => s.id === '背景');
    const split = P.版型 === '上下分割';
    const y = P.分割線 || 960;
    if (split && bg) Object.assign(bg, { x: 0, y, w: 1080, h: 1920 - y });
    return { split, top: split ? { x: 0, y: 0, w: 1080, h: y } : { x: 0, y: 0, w: 1080, h: 1920 }, bottomY: split ? y : 1920 };
  };

  /**
   * 貼紙雙描邊字
   * lines: [{ 字: '留言「剪片」', 字級: 120, 色: '#FFDD3C', 重點: '剪片', 重點色: '#E3301C' }, …]
   * opts: { 墨邊: 10, 白邊: 22, 行距: 1.1, 對齊: 'center' }
   */
  M.貼紙字 = function (lines, opts = {}) {
    const ink = opts.墨邊 ?? 10, white = opts.白邊 ?? 22;
    const wrap = document.createElement('div');
    wrap.className = 'mfx-sticker';
    wrap.style.cssText = `position:absolute;display:flex;flex-direction:column;align-items:${opts.對齊 === 'left' ? 'flex-start' : 'center'};`;
    for (const L of lines) {
      const size = L.字級 || 100;
      const row = document.createElement('div');
      row.style.cssText = `display:grid;line-height:${opts.行距 || 1.12};font:900 ${size}px 'LINE Seed TW';letter-spacing:0.02em;white-space:pre;`;
      const html = (color, kcolor) => {
        const s = R.esc(L.字);
        if (!L.重點) return `<span style="color:${color}">${s}</span>`;
        const k = R.esc(L.重點);
        return s.split(k).map((p) => `<span style="color:${color}">${p}</span>`).join(`<span style="color:${kcolor}">${k}</span>`);
      };
      const sw = (L.縮邊 ?? 1) * (size / 100);
      const layers = [
        // 淡陰影：往下錯開的一層半透明黑（不用 filter 模糊：模糊在縮放時每次出檔會差幾個色階）
        `-webkit-text-stroke:${(ink + white) * 2 * sw}px #000;color:#000;opacity:.2;transform:translateY(${7 * sw}px);`,
        // 外圈白邊
        `-webkit-text-stroke:${(ink + white) * 2 * sw}px #fff;color:#fff;`,
        // 墨黑描邊
        `-webkit-text-stroke:${ink * 2 * sw}px ${M.色.墨};color:${M.色.墨};`,
        // 字本身
        ``,
      ];
      layers.forEach((css, i) => {
        const d = document.createElement('div');
        d.style.cssText = `grid-area:1/1;position:relative;z-index:${i};${css}`;
        d.innerHTML = i < layers.length - 1 ? `<span>${R.esc(L.字)}</span>` : html(L.色 || M.色.黃, L.重點色 || M.色.紅);
        row.appendChild(d);
      });
      wrap.appendChild(row);
    }
    return wrap;
  };

  /** cubic-bezier(x1,y1,x2,y2)：回傳 p(0–1) → 進度 */
  M.bezier = function (x1, y1, x2, y2) {
    const bx = (u) => 3 * x1 * u * (1 - u) ** 2 + 3 * x2 * u * u * (1 - u) + u ** 3;
    const by = (u) => 3 * y1 * u * (1 - u) ** 2 + 3 * y2 * u * u * (1 - u) + u ** 3;
    return (p) => {
      if (p <= 0) return 0;
      if (p >= 1) return 1;
      let lo = 0, hi = 1;
      for (let i = 0; i < 40; i++) { const m = (lo + hi) / 2; if (bx(m) < p) lo = m; else hi = m; }
      return by((lo + hi) / 2);
    };
  };

  /** 紅筆手繪勾：回傳 { svg, set(p) }，p = 0–1 畫出來的比例 */
  M.勾 = function (size = 64, color = M.色.紅, width = 9) {
    const ns = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(ns, 'svg');
    svg.setAttribute('viewBox', '0 0 64 64');
    svg.setAttribute('width', size); svg.setAttribute('height', size);
    svg.style.overflow = 'visible';
    const path = document.createElementNS(ns, 'path');
    // 有點歪的手寫勾：短邊往下、長邊往右上甩出去
    path.setAttribute('d', 'M 6 34 C 12 38, 17 44, 23 53 C 30 38, 42 20, 62 4');
    Object.entries({ fill: 'none', stroke: color, 'stroke-width': width, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' })
      .forEach(([k, v]) => path.setAttribute(k, v));
    svg.appendChild(path);
    let len = 0;
    const set = (p) => {
      if (!len) len = path.getTotalLength() || 90;
      path.setAttribute('stroke-dasharray', len);
      path.setAttribute('stroke-dashoffset', (len * (1 - R.clamp(p))).toFixed(2));
      svg.style.visibility = p > 0 ? 'visible' : 'hidden';
    };
    return { svg, set };
  };

  /** 建一個絕對定位的 div */
  M.div = function (parent, css = '', html = '') {
    const d = document.createElement('div');
    d.style.cssText = 'position:absolute;box-sizing:border-box;' + css;
    if (html) d.innerHTML = html;
    parent.appendChild(d);
    return d;
  };

  window.MFX = M;
})();
